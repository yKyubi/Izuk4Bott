const Izuk4menu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do Izuk4Bot*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  TRADUZIDO POR *MIDORIYA*
  DUVIDAS? 👇
  WA.me/+5527996987396
╚════════════════════`
}

exports.darkmenu = darkmenu








